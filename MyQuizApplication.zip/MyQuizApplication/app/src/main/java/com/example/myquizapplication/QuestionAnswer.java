package com.example.myquizapplication;
public class QuestionAnswer {

    public static String question[] ={
            "How to stop the services in android?",
            "Which permissions are required to get a location in android?",
            "What is APK in android?",
            " What is anchor view?"
    };

    public static String choices[][] = {
            {"finish()","system.exit()","By manually","stopSelf() and stopService()"},
            {"ACCESS_FINE and ACCESS_COARSE"," GPRS permission","Internet permission","WIFI permission"},
            {" Android packages"," Android pack","Android packaging kit"," None of the above"},
            {"Same as list view","provides the information on respective relative positions","Same as relative layout"," None of the above"}
    };

    public static String correctAnswers[] = {
            "stopSelf() and stopService()",
            "ACCESS_FINE and ACCESS_COARSE",
            "Android packaging kit",
            "provides the information on respective relative positions"
    };

}